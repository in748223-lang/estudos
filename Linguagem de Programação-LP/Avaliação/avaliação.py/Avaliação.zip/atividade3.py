def soma(a, b):
    s= a+b
    print (s)


soma(5, 3)

# função de dois números 
with open ("alunos.txt","w") as arquivo:
    arquivo.write("Rafaela, Ingrid, Rian")
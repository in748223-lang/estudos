def saudacao(nome = "visitante"):
    no = nome 
    if no == nome:
     print("Boas Vindas", no)
    else:
     print("Boas Vindas",nome)

saudacao()
   

    

import pyautogui
import time

time.sleep(2 )
pyautogui.dragRel( 100,0,duration=2)
pyautogui.dragRel(0,100,duration=2)
pyautogui.dragRel(-100,0, duration=2)
pyautogui.dragRel(0,-100, duration=2)
 
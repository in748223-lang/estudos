import pyautogui
import time 

pyautogui.press("win")
pyautogui.write("chorme")
pyautogui.press("enter")
time.sleep(1)
pyautogui.write("you tube ")
pyautogui.press("enter")
pyautogui.click(x = 1058, y = 440,duration =1 )
pyautogui.click(x = 1297, y = 167,duration =1 )
time.sleep(1)
pyautogui.click(x = 1335, y = 162,duration =1 )
pyautogui.write("musica relaxante")
pyautogui.press("enter")


import pyautogui
import time

print("O programa vai clicar em 3 segundos...")
time.sleep(3)
pyautogui.click(x=100, y=750)  # altere as coordenadas conforme seu computador